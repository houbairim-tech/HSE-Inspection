# Serveur local HSE 107E (secours si Python est absent). Origine fixe http://localhost:8107
$port = 8107
$root = (Resolve-Path (Join-Path $PSScriptRoot "..\app\src\main\assets")).Path
$mime = @{ ".html"="text/html; charset=utf-8"; ".js"="text/javascript"; ".json"="application/json"; ".webmanifest"="application/manifest+json"; ".png"="image/png"; ".jpg"="image/jpeg"; ".ico"="image/x-icon"; ".css"="text/css"; ".txt"="text/plain" }
$l = New-Object System.Net.HttpListener
$l.Prefixes.Add("http://localhost:$port/")
try { $l.Start() } catch { Start-Process "http://localhost:$port/index.html"; exit }
Start-Process "http://localhost:$port/index.html"
while ($l.IsListening) {
  $c = $l.GetContext()
  $p = [Uri]::UnescapeDataString($c.Request.Url.AbsolutePath.TrimStart("/")); if ($p -eq "") { $p = "index.html" }
  $f = Join-Path $root $p
  if ((Test-Path $f -PathType Leaf) -and ((Resolve-Path $f).Path.StartsWith($root))) {
    $e = [IO.Path]::GetExtension($f).ToLower(); $c.Response.ContentType = $(if ($mime[$e]) { $mime[$e] } else { "application/octet-stream" })
    $b = [IO.File]::ReadAllBytes($f); $c.Response.OutputStream.Write($b, 0, $b.Length)
  } else { $c.Response.StatusCode = 404 }
  $c.Response.Close()
}

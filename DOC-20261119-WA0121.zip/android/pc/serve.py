#!/usr/bin/env python3
"""Serveur local HSE 107E (PC). Origine fixe http://localhost:8107 => données stables, hors ligne, PWA installable."""
import http.server, socketserver, os, sys, webbrowser, threading
PORT = int(os.environ.get("HSE_PORT", "8107"))
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "assets")
if not os.path.isdir(ROOT):
    ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app")
class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      ".webmanifest": "application/manifest+json", ".js": "text/javascript"}
    def __init__(self, *a, **k): super().__init__(*a, directory=ROOT, **k)
    def end_headers(self):
        self.send_header("Cache-Control", "no-cache"); super().end_headers()
    def log_message(self, *a): pass
class S(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
if __name__ == "__main__":
    try:
        srv = S(("127.0.0.1", PORT), H)
    except OSError:
        print("Port %d déjà utilisé : HSE 107E est probablement déjà lancé." % PORT)
        webbrowser.open("http://localhost:%d/index.html" % PORT); sys.exit(0)
    url = "http://localhost:%d/index.html" % PORT
    print("HSE 107E : %s  (Ctrl+C pour arrêter)" % url)
    if "--no-browser" not in sys.argv: threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try: srv.serve_forever()
    except KeyboardInterrupt: pass

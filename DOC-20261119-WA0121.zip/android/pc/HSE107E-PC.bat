@echo off
rem Lance HSE 107E sur PC (Windows). Nécessite Python 3 OU utilise PowerShell en secours.
cd /d "%~dp0"
where python >nul 2>nul && (python serve.py & exit /b)
where py >nul 2>nul && (py -3 serve.py & exit /b)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"

# HSE 107E V3.0.0 — Android + PC (offline first)

Une seule base de code (`app/src/main/assets/`) pour Android et PC. Fonctionne hors ligne et en ligne.
Pas de serveur pour l'instant : les données restent sur l'appareil. Utiliser **Sauvegarde / Restauration** pour déplacer les données (photos incluses).

## Android
- GitHub : pousser sur `main` → Actions produit debug APK, release APK et AAB (artifact `HSE107E-V3`).
- Signature release (optionnelle) : secrets `HSE_KEYSTORE_B64`, `HSE_KEYSTORE_PASSWORD`, `HSE_KEY_ALIAS`, `HSE_KEY_PASSWORD`. Sans eux, la release n'est pas signée.
- Local : Gradle 8.7 + JDK 17 + Android SDK 35 → `gradle assembleDebug` / `bundleRelease`.
- Excel hors ligne : le workflow télécharge SheetJS dans `libs/`. En local, copier `xlsx.full.min.js` dans `app/src/main/assets/libs/`. Sans lui, « Exporter Excel » bascule sur CSV.
- Les exports sont enregistrés dans `Téléchargements/HSE107E`.
- La mise à jour garde les données (même origine `file:///android_asset`).

## PC (Windows / Mac / Linux)
- Windows : double-clic sur `pc/HSE107E-PC.bat` (Python 3, sinon PowerShell). Linux/Mac : `python3 pc/serve.py`.
- Ouvre http://localhost:8107 (adresse fixe = données stables). Dans Chrome/Edge : « Installer l'application » pour une icône et un mode hors ligne complet.
- Les données Android/ancien `file://` ne passent pas automatiquement : faire une Sauvegarde puis une Restauration.

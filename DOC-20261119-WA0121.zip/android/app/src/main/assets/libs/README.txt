Offline Excel support placeholder.
The original application expects libs/xlsx.full.min.js. In this rebuild the app no longer depends on a remote CDN and provides CSV/JSON backup/export offline. To enable full XLSX import/export offline, place SheetJS xlsx.full.min.js here.

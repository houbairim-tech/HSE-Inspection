/* HSE 107E V3 — Service Worker (PC / navigateur uniquement ; l'appli Android sert ses assets en local). */
const CACHE='hse107e-v3-3.0.0';
const CORE=['./','./index.html','./manifest.webmanifest','./icon.png','./libs/xlsx.full.min.js'];
self.addEventListener('install',e=>e.waitUntil(
  caches.open(CACHE).then(c=>Promise.all(CORE.map(u=>c.add(u).catch(()=>null)))).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(
  caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const r=e.request;
  if(r.method!=='GET'||!/^https?:/.test(r.url))return;
  // Cache d'abord (hors ligne), puis réseau ; le réseau met le cache à jour (en ligne).
  e.respondWith(caches.match(r).then(hit=>{
    const net=fetch(r).then(res=>{if(res&&res.ok&&new URL(r.url).origin===location.origin){const c=res.clone();caches.open(CACHE).then(k=>k.put(r,c))}return res}).catch(()=>null);
    return hit||net.then(res=>res||caches.match('./index.html'));
  }));
});

@echo off
where gradle >nul 2>nul || (echo Gradle non trouve. Utilisez GitHub Actions ou installez Gradle 8.7. & pause & exit /b 1)
gradle assembleDebug --no-daemon
pause
